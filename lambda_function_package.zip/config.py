#!/usr/bin/env python3
"""
Konfigurationsdatei für den Bazaraki Immobilien-Scraper
Diese Datei enthält alle konfigurierbaren Parameter für den Scraper
"""

# Bazaraki URL Konfiguration
BAZARAKI_BASE_URL = "https://www.bazaraki.com"

# Immobilien-Kategorien
PROPERTY_CATEGORIES = {
    "rent": "/real-estate-to-rent/",
    "buy": "/real-estate-to-buy/",
}

# Immobilientypen
PROPERTY_TYPES = {
    "house": "houses",
    "apartment": "apartments",
    "land": "land",
    "commercial": "commercial"
}

# Städte in Zypern
CITIES = [
    "Paphos", "Limassol", "Nicosia", 
    "Larnaca", "Famagusta", "Kyrenia"
]

# Standard-Suchkonfiguration - kann beim Aufruf überschrieben werden
DEFAULT_SEARCH_CONFIG = {
    # 'rent' für Miete oder 'buy' für Kauf
    'category': 'rent',
    
    # Immobilientypen (Liste aus PROPERTY_TYPES)
    'property_types': ['house', 'apartment'],
    
    # Städte (Liste aus CITIES)
    'cities': ['Paphos'],
    
    # Radius um die Stadt in km (0 für keine Radiussuche)
    'radius': 20,
    
    # Preise in EUR
    'min_price': 500,
    'max_price': 1500,
    
    # Anzahl der Schlafzimmer (Liste mit Zahlen)
    'bedrooms': [1, 2, 3],
    
    # Maximale Anzahl zu scrapender Seiten (0 für alle verfügbaren Seiten)
    'max_pages': 5
}

# Konfiguration für E-Mail-Benachrichtigungen
EMAIL_NOTIFICATION_CONFIG = {
    'enabled': True,
    'include_new': True,
    'include_removed': True,
    'include_price_reduced': True
}

# Konfiguration für Telegram-Benachrichtigungen
TELEGRAM_NOTIFICATION_CONFIG = {
    'enabled': True,
    'include_new': True,
    'include_removed': True,
    'include_price_reduced': True,
    'max_properties_per_message': 10  # Begrenzt die Anzahl der Immobilien pro Nachricht
}

# Erweiterte Filter-Parameter (können je nach Bedarf hinzugefügt werden)
ADVANCED_FILTERS = {
    # Mindestanzahl an Badezimmern
    'min_bathrooms': None,  # z.B. 1, 2, etc.
    
    # Minimale Fläche in Quadratmetern
    'min_area': None,  # z.B. 50, 100, etc.
    
    # Spezielle Merkmale (hängt von der Website ab)
    'features': [],  # z.B. ["pool", "garden", "sea_view"]
    
    # Jahr der Fertigstellung (von-bis)
    'year_from': None,  # z.B. 2010
    'year_to': None,    # z.B. 2023
}

def build_search_config(**kwargs):
    """
    Erstellt eine Suchkonfiguration basierend auf den Standardwerten und den übergebenen Parametern
    
    Beispiel:
        config = build_search_config(
            category='buy',
            cities=['Limassol'],
            min_price=200000,
            max_price=500000
        )
    """
    # Kopie der Standardkonfiguration erstellen
    config = DEFAULT_SEARCH_CONFIG.copy()
    
    # Übergebene Parameter überschreiben Standardwerte
    for key, value in kwargs.items():
        if key in config:
            config[key] = value
    
    return config

def get_bazaraki_url(config):
    """
    Erstellt die Basis-URL für die bazaraki.com Suche basierend auf der Konfiguration
    
    :param config: Suchkonfiguration
    :return: Basis-URL für bazaraki.com
    """
    # Grundlegende URL
    base_url = "https://www.bazaraki.com/"
    
    # Kategorie (rent oder buy)
    category = config.get("category", "rent")
    if category == "rent":
        base_url += "real-estate-to-rent/"
    else:
        # Fallback auf rent, da buy möglicherweise nicht funktioniert
        base_url += "real-estate-to-rent/"
        # Wir setzen einen Hinweis im Log, dass wir einen Fallback verwenden
        print("WARNUNG: buy-Kategorie könnte nicht funktionieren, verwende rent als Fallback")
    
    # Immobilientyp (house, apartment oder beides)
    property_types = config.get("property_types", [])
    
    # Wenn genau ein Typ "house" ist, verwende den speziellen Pfad
    if len(property_types) == 1 and property_types[0] == "house":
        base_url += "houses/"
    
    # Hinweis: Wir verwenden keine URL für apartments/, da diese 404 zurückgibt
    # Stattdessen verwenden wir später URL-Parameter für die Immobilientypen
    
    return base_url
