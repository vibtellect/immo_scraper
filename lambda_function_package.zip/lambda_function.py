#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Bazaraki Lambda Scraper - Optimiert für AWS Lambda
Speziell entwickelt für das Terraform-basierte Projekt zur Überwachung von Immobilienangeboten
"""

import os
import time
import json
import boto3
import random
import logging
import requests
import hashlib
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional
from urllib.parse import urlencode

# Logging konfigurieren
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS Konfiguration aus Umgebungsvariablen
S3_BUCKET_NAME = os.environ.get('S3_BUCKET_NAME', 'bazaraki-scraper-results')
RESULTS_PREFIX = os.environ.get('RESULTS_PREFIX', 'results/')
TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '')
TELEGRAM_CHAT_ID = os.environ.get('TELEGRAM_CHAT_ID', '')

# Liste von gängigen User-Agents zur Rotation
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:115.0) Gecko/20100101 Firefox/115.0',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
]

# Geo-Koordinaten für Standorte
GEO_LOCATIONS = {
    'paphos': {
        'lat': 34.797537264230336,
        'lng': 32.434836385742194,
        'radius': 10000  # 10km Radius
    },
    'limassol': {
        'lat': 34.684422,
        'lng': 33.037085,
        'radius': 10000  # 10km Radius
    }
}

class BazarakiLambdaScraper:
    """
    Optimierter Scraper für Bazaraki, speziell für AWS Lambda.
    Verwendet Cookie-basierte Authentifizierung und simuliert einen echten Browser.
    """
    
    # Basis-URLs
    BASE_URL = "https://www.bazaraki.com"
    
    def __init__(self):
        """Initialisiere den Lambda-Scraper."""
        self.session = requests.Session()
        self.cookies = {}
        self.fingerprint = self._generate_fingerprint()
        self.s3_client = boto3.client('s3')
        self.previous_results = None
        logger.info(f"Bazaraki Lambda Scraper initialisiert. Fingerprint: {self.fingerprint[:8]}")
    
    def _generate_fingerprint(self) -> str:
        """Generiert einen eindeutigen Browser-Fingerprint."""
        platform = random.choice(["Windows", "MacOS", "Linux"])
        browser = random.choice(["Chrome", "Firefox", "Safari"])
        instance_id = os.environ.get('AWS_LAMBDA_LOG_STREAM_NAME', f"local-{datetime.now().timestamp()}")
        fingerprint_data = f"{platform}|{browser}|{instance_id}"
        return hashlib.sha256(fingerprint_data.encode()).hexdigest()
    
    def _get_random_headers(self) -> Dict[str, str]:
        """Generiert zufällige HTTP-Header für natürlich wirkende Anfragen."""
        user_agent = random.choice(USER_AGENTS)
        
        headers = {
            'User-Agent': user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9,de;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Referer': 'https://www.google.com/',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'cross-site',
            'Cache-Control': 'max-age=0',
        }
        
        # Zufällig einige Header weglassen
        headers_to_remove = random.sample([
            'DNT', 'Cache-Control', 'Sec-Fetch-Dest', 'Sec-Fetch-Mode', 'Sec-Fetch-Site'
        ], k=random.randint(0, 2))
        
        for header in headers_to_remove:
            if header in headers:
                del headers[header]
        
        return headers
    
    def _make_request(self, url: str, delay: bool = True) -> Optional[requests.Response]:
        """Führt eine HTTP-Anfrage durch und umgeht Anti-Scraping-Maßnahmen."""
        if delay:
            time.sleep(random.uniform(1, 3))
        
        headers = self._get_random_headers()
        
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                response = self.session.get(
                    url,
                    headers=headers,
                    cookies=self.cookies,
                    timeout=(10, 30),
                    allow_redirects=True
                )
                
                if response.cookies:
                    self.cookies.update(dict(response.cookies))
                
                if response.status_code < 400:
                    logger.info(f"Erfolgreicher Request: {url} - Status: {response.status_code}")
                    if delay:
                        time.sleep(random.uniform(1, 2))
                    return response
                
                logger.warning(f"Fehler beim Request zu {url} - Status: {response.status_code}")
                retry_count += 1
                time.sleep(random.uniform(5, 10))
                
            except requests.exceptions.RequestException as e:
                logger.error(f"Netzwerkfehler bei {url}: {str(e)}")
                retry_count += 1
                time.sleep(random.uniform(5, 10))
        
        logger.error(f"Maximale Anzahl von Wiederholungsversuchen erreicht für {url}")
        return None
    
    def _initialize_session(self) -> bool:
        """Initialisiert eine Browsing-Sitzung mit der Bazaraki-Website."""
        logger.info("Initialisiere Bazaraki-Sitzung...")
        
        main_response = self._make_request("https://www.bazaraki.com/")
        if not main_response:
            logger.error("Konnte keine Verbindung zur Bazaraki-Hauptseite herstellen")
            return False
        
        property_response = self._make_request("https://www.bazaraki.com/real-estate-to-rent/")
        if not property_response:
            logger.warning("Konnte keine Verbindung zur Immobilienseite herstellen")
        
        logger.info(f"Sitzung initialisiert. {len(self.cookies)} Cookies erhalten.")
        return True
    
    def get_property_listings(self, 
                            location: str = "paphos", 
                            deal_type: str = "rent",
                            property_type: str = "apartments",
                            min_price: Optional[int] = None,
                            max_price: Optional[int] = None,
                            min_bedrooms: Optional[int] = None,
                            max_pages: int = 3) -> List[Dict]:
        """
        Holt Immobilienanzeigen von Bazaraki basierend auf bestimmten Suchkriterien.
        
        Args:
            location: Standort ("paphos" oder "limassol")
            deal_type: Transaktionstyp ("rent" oder "buy")
            property_type: Immobilientyp ("apartments" oder "houses")
            min_price: Minimaler Preis
            max_price: Maximaler Preis
            min_bedrooms: Minimale Anzahl an Schlafzimmern
            max_pages: Maximale Anzahl an Seiten zum Scrapen
            
        Returns:
            Liste von Immobilienanzeigen
        """
        # Sitzung initialisieren
        if not self.cookies:
            if not self._initialize_session():
                return []
        
        # URL-Basis basierend auf Transaktionstyp und Immobilientyp
        if deal_type.lower() == "rent":
            url_path = "/real-estate-to-rent/"
        else:
            url_path = "/real-estate-to-buy/"
        
        if property_type.lower() == "apartments":
            url_path += "apartments-flats/"
        elif property_type.lower() == "houses":
            url_path += "houses/"
        
        # Parameter zusammenstellen
        params = {}
        
        # Geo-Koordinaten für den Standort
        if location.lower() in GEO_LOCATIONS:
            geo = GEO_LOCATIONS[location.lower()]
            params['lat'] = geo['lat']
            params['lng'] = geo['lng']
            params['radius'] = geo['radius']
        
        # Preisfilter
        if min_price is not None:
            params['price_min'] = min_price
        if max_price is not None:
            params['price_max'] = max_price
        
        # Schlafzimmerfilter
        if min_bedrooms is not None:
            params['bedrooms_min'] = min_bedrooms
        
        # Ergebnisliste
        all_listings = []
        
        # Durch die Seiten iterieren
        for page in range(1, max_pages + 1):
            # Aktualisierte Parameter für die aktuelle Seite
            current_params = params.copy()
            current_params['page'] = page
            
            # URL für die aktuelle Seite erstellen
            url = f"{self.BASE_URL}{url_path}?{urlencode(current_params)}"
            
            logger.info(f"Scrape Seite {page} von {max_pages}: {url}")
            
            # Seite abrufen
            response = self._make_request(url)
            if not response:
                logger.error(f"Konnte Seite {page} nicht abrufen")
                break
            
            # Listings aus der Antwort extrahieren
            page_listings = self._extract_listings_from_html(response.text)
            
            if not page_listings:
                logger.info(f"Keine Anzeigen auf Seite {page} gefunden")
                break
            
            logger.info(f"{len(page_listings)} Anzeigen auf Seite {page} gefunden")
            all_listings.extend(page_listings)
            
            # Pause zwischen den Seiten
            if page < max_pages:
                time.sleep(random.uniform(3, 7))
        
        logger.info(f"Insgesamt {len(all_listings)} Immobilienanzeigen gefunden")
        return all_listings
    
    def _extract_listings_from_html(self, html_content: str) -> List[Dict]:
        """
        Extrahiert Immobilienanzeigen aus der HTML-Antwort.
        
        Dies ist die komplexeste Funktion, die angepasst werden muss, 
        wenn Bazaraki seine HTML-Struktur ändert.
        """
        listings = []
        
        # Nach dem vorhandenen HTML-Muster von Immobilienanzeigen suchen
        # Hier würde eine vollständige Implementierung folgen, die 
        # an die aktuelle HTML-Struktur angepasst ist
        
        # Dies ist ein Platzhalter - für eine funktionierende Implementierung
        # müsste die genaue HTML-Struktur analysiert werden
        
        return listings
    
    def load_previous_results(self) -> Dict:
        """
        Lädt die Ergebnisse des vorherigen Scraping-Laufs aus S3.
        
        Returns:
            Dictionary mit vorherigen Ergebnissen oder leeres Dictionary bei Fehler
        """
        try:
            # Berechne den Dateinamen für die vorherigen Ergebnisse
            yesterday = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
            filename = f"{RESULTS_PREFIX}{yesterday.strftime('%Y-%m-%d')}.json"
            
            logger.info(f"Lade vorherige Ergebnisse aus S3: {S3_BUCKET_NAME}/{filename}")
            
            response = self.s3_client.get_object(
                Bucket=S3_BUCKET_NAME,
                Key=filename
            )
            
            content = response['Body'].read().decode('utf-8')
            previous_results = json.loads(content)
            
            logger.info(f"Vorherige Ergebnisse geladen: {len(previous_results.get('listings', []))} Anzeigen")
            return previous_results
            
        except Exception as e:
            logger.warning(f"Konnte vorherige Ergebnisse nicht laden: {str(e)}")
            return {}
    
    def save_results(self, results: Dict) -> bool:
        """
        Speichert die Scraping-Ergebnisse in S3.
        
        Args:
            results: Dictionary mit Scraping-Ergebnissen
            
        Returns:
            True bei Erfolg, False bei Fehler
        """
        try:
            # Aktuelles Datum für den Dateinamen
            today = datetime.now(timezone.utc)
            filename = f"{RESULTS_PREFIX}{today.strftime('%Y-%m-%d')}.json"
            
            # Ergebnisse als JSON speichern
            content = json.dumps(results, ensure_ascii=False)
            
            logger.info(f"Speichere Ergebnisse in S3: {S3_BUCKET_NAME}/{filename}")
            
            self.s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=filename,
                Body=content.encode('utf-8'),
                ContentType='application/json'
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Fehler beim Speichern der Ergebnisse: {str(e)}")
            return False
    
    def compare_results(self, previous_results: Dict, current_results: Dict) -> Dict:
        """
        Vergleicht die aktuellen Ergebnisse mit den vorherigen, um neue und entfernte Anzeigen zu identifizieren.
        
        Args:
            previous_results: Ergebnisse des vorherigen Laufs
            current_results: Aktuelle Ergebnisse
            
        Returns:
            Dictionary mit neuen und entfernten Anzeigen
        """
        # Anzeigen aus den Ergebnissen extrahieren
        previous_listings = previous_results.get('listings', [])
        current_listings = current_results.get('listings', [])
        
        # Anzeigen-IDs extrahieren
        previous_ids = {listing['id'] for listing in previous_listings}
        current_ids = {listing['id'] for listing in current_listings}
        
        # Neue und entfernte Anzeigen identifizieren
        new_ids = current_ids - previous_ids
        removed_ids = previous_ids - current_ids
        
        # Vollständige Anzeigendaten für neue und entfernte Anzeigen sammeln
        new_listings = [listing for listing in current_listings if listing['id'] in new_ids]
        removed_listings = [listing for listing in previous_listings if listing['id'] in removed_ids]
        
        logger.info(f"Vergleich abgeschlossen: {len(new_listings)} neue und {len(removed_listings)} entfernte Anzeigen")
        
        return {
            'new_listings': new_listings,
            'removed_listings': removed_listings
        }
    
    def send_telegram_notification(self, changes: Dict) -> bool:
        """
        Sendet eine Benachrichtigung über Änderungen via Telegram.
        
        Args:
            changes: Dictionary mit neuen und entfernten Anzeigen
            
        Returns:
            True bei Erfolg, False bei Fehler
        """
        # Prüfen, ob Telegram-Konfiguration vorhanden ist
        if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
            logger.warning("Telegram-Konfiguration fehlt. Keine Benachrichtigung gesendet.")
            return False
        
        try:
            # Nachrichtentext erstellen
            new_listings = changes.get('new_listings', [])
            removed_listings = changes.get('removed_listings', [])
            
            message_parts = ["*Bazaraki Immobilien-Update*\n"]
            
            # Informationen zu neuen Anzeigen
            if new_listings:
                message_parts.append(f"*{len(new_listings)} neue Anzeigen gefunden:*\n")
                for i, listing in enumerate(new_listings[:5], 1):  # Top 5 anzeigen
                    title = listing.get('title', 'Keine Beschreibung')
                    price = listing.get('price', '?')
                    currency = listing.get('currency', '€')
                    url = listing.get('url', '')
                    message_parts.append(f"{i}. [{title}]({url}) - {price} {currency}")
                
                if len(new_listings) > 5:
                    message_parts.append(f"...und {len(new_listings) - 5} weitere neue Anzeigen.")
            else:
                message_parts.append("Keine neuen Anzeigen.")
            
            # Informationen zu entfernten Anzeigen
            if removed_listings:
                message_parts.append(f"\n*{len(removed_listings)} Anzeigen entfernt:*\n")
                for i, listing in enumerate(removed_listings[:5], 1):  # Top 5 anzeigen
                    title = listing.get('title', 'Keine Beschreibung')
                    price = listing.get('price', '?')
                    currency = listing.get('currency', '€')
                    message_parts.append(f"{i}. {title} - {price} {currency}")
                
                if len(removed_listings) > 5:
                    message_parts.append(f"...und {len(removed_listings) - 5} weitere entfernte Anzeigen.")
            else:
                message_parts.append("\nKeine entfernten Anzeigen.")
            
            # Nachricht zusammensetzen
            message = '\n'.join(message_parts)
            
            # Telegram API-URL
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
            
            # Nachricht senden
            response = requests.post(url, data={
                'chat_id': TELEGRAM_CHAT_ID,
                'text': message,
                'parse_mode': 'Markdown',
                'disable_web_page_preview': True
            })
            
            if response.status_code == 200:
                logger.info("Telegram-Benachrichtigung erfolgreich gesendet")
                return True
            else:
                logger.error(f"Fehler beim Senden der Telegram-Benachrichtigung: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Fehler beim Senden der Telegram-Benachrichtigung: {str(e)}")
            return False


# AWS Lambda Handler
def lambda_handler(event, context):
    """
    AWS Lambda Handler-Funktion.
    
    Args:
        event: Lambda-Event (kann Konfigurationsparameter enthalten)
        context: Lambda-Kontext
        
    Returns:
        Dictionary mit Statuscode und Ergebnissen
    """
    logger.info("Starte Bazaraki Lambda Scraper")
    
    try:
        # Scraper initialisieren
        scraper = BazarakiLambdaScraper()
        
        # Konfiguration aus Event oder Standardwerte
        config = event.get('config', {})
        location = config.get('location', 'paphos')
        deal_type = config.get('deal_type', 'rent')
        property_type = config.get('property_type', 'apartments')
        min_price = config.get('min_price')
        max_price = config.get('max_price')
        min_bedrooms = config.get('min_bedrooms')
        
        # Immobilienanzeigen scrapen
        listings = scraper.get_property_listings(
            location=location,
            deal_type=deal_type,
            property_type=property_type,
            min_price=min_price,
            max_price=max_price,
            min_bedrooms=min_bedrooms
        )
        
        if not listings:
            logger.warning("Keine Immobilienanzeigen gefunden.")
            return {
                'statusCode': 200,
                'body': {
                    'message': 'Keine Immobilienanzeigen gefunden.',
                    'timestamp': datetime.now(timezone.utc).isoformat()
                }
            }
        
        # Aktuelle Ergebnisse
        current_results = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'config': {
                'location': location,
                'deal_type': deal_type,
                'property_type': property_type,
                'min_price': min_price,
                'max_price': max_price,
                'min_bedrooms': min_bedrooms
            },
            'listings': listings
        }
        
        # Vorherige Ergebnisse laden
        previous_results = scraper.load_previous_results()
        
        # Ergebnisse speichern
        scraper.save_results(current_results)
        
        # Änderungen identifizieren, wenn vorherige Ergebnisse verfügbar sind
        changes = {}
        if previous_results:
            changes = scraper.compare_results(previous_results, current_results)
            
            # Benachrichtigung senden, wenn Änderungen vorhanden sind
            if changes.get('new_listings') or changes.get('removed_listings'):
                scraper.send_telegram_notification(changes)
        
        # Erfolgreiche Antwort
        return {
            'statusCode': 200,
            'body': {
                'message': f"Scraping erfolgreich abgeschlossen. {len(listings)} Anzeigen gefunden.",
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'config': current_results['config'],
                'listings_count': len(listings),
                'changes': {
                    'new_count': len(changes.get('new_listings', [])),
                    'removed_count': len(changes.get('removed_listings', []))
                }
            }
        }
        
    except Exception as e:
        logger.error(f"Fehler beim Ausführen des Scrapers: {str(e)}")
        
        # Fehlerantwort
        return {
            'statusCode': 500,
            'body': {
                'message': f"Fehler: {str(e)}",
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
        }


# Für lokale Tests
if __name__ == "__main__":
    # Logging konfigurieren
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Scraper testen
    scraper = BazarakiLambdaScraper()
    
    # Immobilienanzeigen in Paphos suchen
    listings = scraper.get_property_listings(
        location="paphos",
        deal_type="rent",
        property_type="apartments",
        min_price=500,
        max_price=1500,
        max_pages=1
    )
    
    # Ergebnisse anzeigen
    print(f"Gefundene Immobilienanzeigen: {len(listings)}")
